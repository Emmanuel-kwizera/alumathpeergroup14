# alumathpeergroup14
A pip library from peer group 14 to perform matrix multiplication.
